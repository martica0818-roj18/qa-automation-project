describe('API Auth Tests', () => {

  const baseUrl = 'https://api.demoblaze.com'

  it('Crear usuario nuevo', () => {
    const username = 'user' + Date.now()
    cy.request({
      method: 'POST',
      url: `${baseUrl}/signup`,
      body: { username, password: '123456' },
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.eq(200)
    })
  })

  it('Login correcto', () => {
    cy.request({
      method: 'POST',
      url: `${baseUrl}/login`,
      body: { username: 'testuser', password: '123456' },
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.eq(200)
    })
  })

})
