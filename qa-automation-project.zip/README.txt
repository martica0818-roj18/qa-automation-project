PROYECTO QA AUTOMATIZACIÓN API

1. Instalar:
npm install

2. Ejecutar:
npx cypress open

3. Casos:
- Registro
- Login
