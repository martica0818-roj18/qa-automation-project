module.exports = {
  e2e: {
    baseUrl: "https://demoblaze.com"
  }
}